module.exports = {
	API_SERVER : 'https://sms-server.ums86.com'//本地环境
}
