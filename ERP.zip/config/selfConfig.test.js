module.exports = {
    API_SERVER : 'http://10.0.0.194:8085'//本地环境
}
