module.exports = {
    API_SERVER : 'http://sms-server.ums86.com'//本地环境
}
