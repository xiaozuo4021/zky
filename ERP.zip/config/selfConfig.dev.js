module.exports = {
    // API_SERVER : 'http://10.0.0.170:9191/mockjsdata/85',//本地环境
    // API_SERVER: 'http://10.0.10.143:8088',//鲍俊
    // API_SERVER: 'http://10.0.10.230:8080/sms-server',//亚兵
    // API_SERVER: 'http://10.0.10.220:8080/sms-server',//敏杰
    API_SERVER: 'http://10.0.0.194:8085'//6.1test
}
