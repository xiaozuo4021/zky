<template>
	<div class="left-menu el-border-master">
		<div class="menu-com sp-menu">
			<div class="menu-com-body">
				<i class="iconfont icon-caidan"></i>
			</div>
		</div>
		<div v-for="(item,i) in menuList" :key="item.id" :class="{'menu-com': true,'active-check': isRouterMatch(item.id)}"  @click="jump(item.link, item.id)">
			<div class="menu-com-body">
				<!--<i :class="item.iconObj"></i>-->
				<i :class="item.icon" class="iconfont"></i>
				<span>{{item.name}}</span>
			</div>
		</div>
		<!--<div class="menu-com">
			<div class="menu-com-body">
				<i class="iconfont icon-renshu"></i>
				<span>会议管理</span>
			</div>
		</div>
		<div class="menu-com">
			<div class="menu-com-body">
				<i class="iconfont icon-1"></i>
				<span>用车管理</span>
			</div>
		</div>
		<div class="menu-com">
			<div class="menu-com-body">
				<i class="iconfont icon-wenjianjia"></i>
				<span>财务管理</span>
			</div>
		</div>
		<div class="menu-com">
			<div class="menu-com-body">
				<i class="iconfont icon-tongxunlu"></i>
				<span>通讯录</span>
			</div>
		</div>
		<div class="menu-com">
			<div class="menu-com-body">
				<i class="iconfont icon-quanxian"></i>
				<span>权限管理</span>
			</div>
		</div>
		<div class="menu-com">
			<div class="menu-com-body">
				<i class="iconfont icon-xitong"></i>
				<span>系统管理</span>
			</div>
		</div>
		<div class="menu-com">
			<div class="menu-com-body">
				<i class="iconfont icon-fabu1"></i>
				<span>内容发布</span>
			</div>
		</div>-->
		<!--<ul v-for="item in menuList" :key="item.id">
			<li class="active">
				<template v-if="!item.children || item.children.length<=0">
					<span class="list-style-bar" :class="{'el-bg-primary': isRouterMatch(item.id)}"></span>
					<h3>
						<a href="javascript:;" @click="jump(item.link, item.id)" class="el-c-hover">
							{{item.name}}
						</a>
					</h3>
				</template>
				<template v-else>
					<a href="javascript:;" @click="toggleSubMenu(item.id)">
						{{item.name}}
						<span class="submenu-indicator"><i class="fa "
														   :class="{'fa-angle-right': item.isChildrenHide,'fa-angle-down': !item.isChildrenHide}"></i></span>
					</a>
					<transition name="fade">
						<div v-show="!item.isChildrenHide">
							<ul class="submenu">
								<li @click="jump(sub.link, sub.id)" v-for="sub in item.children" :key="sub.id">
									<a href="javascript:;" :class="{'a-hover': isRouterMatch(sub.id)}">{{sub.name}}</a>
								</li>
							</ul>
						</div>
					</transition>
				</template>
			</li>
		</ul>-->
	</div>
</template>

<script>
	export default {
		data() {
			return {
				isShow: true
			}
		},
		props: {
			// 菜单列表
			menuList: {
				type: Array,
				required: true
			}
		},
		computed: {

		},
		methods: {
			// 是否匹配当前路由
			isRouterMatch(id) {
				return this.$route.meta.menuId === id
			},
			// 显示/隐藏子菜单
			toggleSubMenu(id) {
				this.$emit('toggle', {id: id})
				this.isShow = !this.isShow
			},
			// 跳转
			jump(link, id) {
				this.$router.push(link)
				this.$emit('initBreadCrumb', id)

			}
		}
	}
</script>

<style scoped rel="stylesheet/sass" lang="sass">
	.sp-menu
		height: 60px!important
		.menu-com-body
			height: 20px!important
			margin-top: -10px


	.active-check
		background-color: #125ed1
		i
			color: #09fffd

	.menu-com:hover
		background-color: #125ed1
		i
			color: #09fffd


	.menu-com-body
		position: absolute
		top: 50%
		left: 50%
		margin-top: -20px
		margin-left: -30px
		width: 60px
		height: 40px
		text-align: center
		span
			display: inline-block
			font-size: 14px
			margin-top: 3px
		i
			display: block
			font-size: 22px
			line-height: 18px
			margin: 0 auto

	.menu-com
		color: #fff
		width: 80px
		height: 80px
		position: relative
		cursor: pointer

	.left-menu
		ul
		background: -webkit-linear-gradient(top, #0839b1, #0070cf) !important

	.a-hover
		border-left-color: #42a5f5 !important
		background-color: #fafcff !important

</style>
