// import * as mt from './mutation-types'

export default {
    /* [mt.GET_SEND_LIST](state, payload) {} */
}
