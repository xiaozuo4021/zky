import Vue from 'vue'
import Router from 'vue-router'

// 组件懒加载，组件会被webpack打包多个js，当路由被访问的时候只加载相应组件js

// App
const App = resolve => require(['@/App'], resolve)

// 基础业务配置
const individualizationSetting = resolve => require(['../components/view/individualizationSetting/individualizationSetting.vue'], resolve)

// 404
const notFound = resolve => require(['@/components/common/notFound.vue'], resolve)
Vue.use(Router)

export default new Router({
	mode: 'history',
	routes: [
		{
			path: '/',
			component: App,
			meta: {keepAlive: false, menuId: '01'},
			children: [
				{
					path: '/individualization/setting',
					component: individualizationSetting,
					meta: {keepAlive: false, menuId: '021'}
				}
			]
		},
		{   // 404
			path: '*',
			component: notFound
		}
	]
})
