export const CONSTANT = {
	//模版来源
	TEMPLATE_CATEGORY: [{value: '1', label: '平台模版'}, {value: '2', label: '接口模版'}],
	TEMPLATE_USE_TYPE: {'1': '平台', '2': '接口'},
	//审核
	AUDIT_STATUS_DISPLAY: {'0': '审核通过', '2': '审核不通过'},
	AUDIT_STATUS: {PASS: '0', FAIL: '2'}
}
